GOVIND YADAV — PERSONAL PORTFOLIO
================================

1. Open index.html in Chrome to preview the website.
2. Replace the placeholder email, LinkedIn and GitHub links with your real details.
3. To publish it for free, upload index.html to a static hosting service such as GitHub Pages or Netlify.
4. A custom domain can be connected later.

The site is responsive and works on mobile and desktop.
